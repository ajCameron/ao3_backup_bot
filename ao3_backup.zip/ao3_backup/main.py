
from __future__ import annotations
import os, time, concurrent.futures, datetime as dt
import click
from sqlalchemy.orm import Session
from sqlalchemy import text

from .config import CLAIM_BATCH, PARALLELISM
from .db import get_engine, create_all, enqueue_range, claim_batch, complete, requeue, works, queue, fetch_log
from .fetch import probe_guest, fetch_authenticated
from .storage import write_html_gz
from .classify import parse_basic_fields
from .sessions import load_credentials

@click.group()
def cli():
    "AO3 crawler skeleton."

@cli.command("initdb")
def initdb():
    create_all()
    click.echo("DB initialized.")

@cli.command("enqueue")
@click.option("--start", type=int, required=True)
@click.option("--stop", type=int, required=True)
@click.option("--mode", type=click.Choice(["guest","auth","update"]), default="guest")
@click.option("--priority", type=int, default=100)
def enqueue_cmd(start: int, stop: int, mode: str, priority: int):
    eng = get_engine()
    with Session(eng) as s, s.begin():
        n = enqueue_range(s, start, stop, mode=mode, priority=priority)
    click.echo(f"Enqueued {n} ids [{start}..{stop}] in mode={mode}")

@cli.command("worker")
@click.option("--mode", type=click.Choice(["guest","auth","update"]), default="guest")
@click.option("--name", type=str, default=None, help="Worker name (default: hostname-pid)")
def worker(mode: str, name: str | None):
    eng = get_engine()
    if name is None:
        name = f"{os.uname().nodename}-{os.getpid()}"
    creds = load_credentials() if mode == "auth" else []

    def handle_one(id_: int):
        try:
            if mode == "guest":
                outcome, http, html, final_url = probe_guest(id_)
            elif mode == "auth":
                outcome, http, html, final_url, err = fetch_authenticated(id_, creds)
                if err:
                    return ("error", http, f"auth-error:{err}", 0)
            else:
                outcome, http, html, final_url = probe_guest(id_)

            size = 0
            if outcome in ("public","unrevealed","restricted"):
                size, sha = write_html_gz(id_, html)
                meta = parse_basic_fields(html)
            else:
                sha, meta = None, {}

            with Session(eng) as s, s.begin():
                if s.bind.dialect.name == "postgresql":
                    s.execute(text("""
                        INSERT INTO works (id, status, http_status, last_seen, last_fetched, content_sha256, size_bytes, title, authors, series, restricted, needs_auth)
                        VALUES (:id, :status, :http, NOW(), CASE WHEN :fetched THEN NOW() ELSE NULL END, :sha, :size, :title, :authors, :series, :restricted, :needs_auth)
                        ON CONFLICT (id) DO UPDATE SET
                          status=EXCLUDED.status,
                          http_status=EXCLUDED.http_status,
                          last_seen=EXCLUDED.last_seen,
                          last_fetched=EXCLUDED.last_fetched,
                          content_sha256=EXCLUDED.content_sha256,
                          size_bytes=EXCLUDED.size_bytes,
                          title=EXCLUDED.title,
                          authors=EXCLUDED.authors,
                          series=EXCLUDED.series,
                          restricted=EXCLUDED.restricted,
                          needs_auth=EXCLUDED.needs_auth
                    """), {
                        "id": id_, "status": outcome, "http": http, "fetched": outcome in ("public","restricted","unrevealed"),
                        "sha": sha, "size": size,
                        "title": meta.get("title"), "authors": meta.get("authors"), "series": meta.get("series"),
                        "restricted": outcome=="restricted", "needs_auth": outcome=="restricted"
                    })
                else:
                    s.execute(text("""
                        INSERT OR REPLACE INTO works (id, status, http_status, last_seen, last_fetched, content_sha256, size_bytes, title, authors, series, restricted, needs_auth)
                        VALUES (:id, :status, :http, datetime('now'), CASE WHEN :fetched THEN datetime('now') ELSE NULL END, :sha, :size, :title, :authors, :series, :restricted, :needs_auth)
                    """), {
                        "id": id_, "status": outcome, "http": http, "fetched": outcome in ("public","restricted","unrevealed"),
                        "sha": sha, "size": size,
                        "title": meta.get("title"), "authors": json.dumps(meta.get("authors") or []), "series": json.dumps(meta.get("series") or []),
                        "restricted": 1 if outcome=="restricted" else 0, "needs_auth": 1 if outcome=="restricted" else 0
                    })
                s.execute(fetch_log.insert().values(id=id_, worker=name, outcome=outcome, http_status=http, size_bytes=size))
                complete(s, id_)
                if outcome == "restricted" and mode == "guest":
                    s.execute(text("""
                        INSERT INTO queue (id, mode, priority) VALUES (:id, 'auth', 50)
                        ON CONFLICT DO NOTHING
                    """), {"id": id_})
            return (outcome, http, None, size)
        except Exception as e:
            with Session(eng) as s, s.begin():
                requeue(s, id_, delay_seconds=300, error_msg=str(e))
            return ("error", 0, str(e), 0)

    while True:
        with Session(eng) as s, s.begin():
            ids = claim_batch(s, name, batch_size=CLAIM_BATCH, mode=mode)
        if not ids:
            time.sleep(2.0)
            continue
        from itertools import repeat
        import json
        with concurrent.futures.ThreadPoolExecutor(max_workers=PARALLELISM) as pool:
            for id_, res in zip(ids, pool.map(handle_one, ids)):
                outcome, http, err, size = res
                click.echo(f"[{mode}] {id_}: {outcome} (http={http}, size={size})" + (f" ERR={err}" if err else ""))

if __name__ == "__main__":
    cli()
