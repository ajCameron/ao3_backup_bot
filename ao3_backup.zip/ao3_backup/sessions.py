
from __future__ import annotations

import json
import time
import requests

from typing import Optional, List

from ao3.requester import Requester

from .config import USER_AGENT, CREDENTIALS_JSON, GUEST_DELAY_S, AUTH_DELAY_S, JITTER_S

_req_guest = Requester(user_agent=USER_AGENT, requests_per_window=60, window_seconds=60.0)


def jitter(base: float) -> float:
    import random
    return base + random.random() * JITTER_S


def guest_get(url: str) -> requests.Response:
    time.sleep(jitter(GUEST_DELAY_S))
    return _req_guest.get(url, allow_redirects=True)


class Credential:
    def __init__(self, username: str, password: str):
        self.username = username
        self.password = password
        self.session: Optional[requests.Session] = None
        self.req: Optional[Requester] = None

    def ensure(self) -> Requester:
        if self.session is None:
            self.session = requests.Session()
            self.req = Requester(user_agent=USER_AGENT, requests_per_window=30, window_seconds=60.0, session=self.session)
            try:
                import ao3
                s = ao3.session.ao3session.Ao3Session(self.username, self.password, force_session=self.session)
                _ = s._authenticity_token
            except Exception as e:
                raise RuntimeError(f"Login failed for {self.username}: {e}") from e
        return self.req  # type: ignore


def load_credentials() -> List[Credential]:
    creds: List[Credential] = []
    try:
        raw = json.loads(CREDENTIALS_JSON)
        for c in raw:
            creds.append(Credential(c["username"], c["password"]))
    except Exception:
        pass
    return creds
