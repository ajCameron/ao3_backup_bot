
from __future__ import annotations
import datetime as dt
from typing import Optional

from sqlalchemy import (
    create_engine, MetaData, Table, Column, Integer, BigInteger, String, Text, Boolean,
    DateTime, JSON, Index, func, text, select, insert, update
)
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from .config import DB_URL

metadata = MetaData(schema=None)

works = Table(
    "works", metadata,
    Column("id", BigInteger, primary_key=True),
    Column("status", String(32), nullable=False),   # public|restricted|unrevealed|not_found|error
    Column("http_status", Integer, nullable=True),
    Column("last_seen", DateTime, nullable=False, server_default=func.now()),
    Column("last_fetched", DateTime, nullable=True),
    Column("content_sha256", String(64), nullable=True),
    Column("size_bytes", Integer, nullable=True),
    Column("title", Text, nullable=True),
    Column("authors", JSON, nullable=True),
    Column("series", JSON, nullable=True),
    Column("words", Integer, nullable=True),
    Column("chapters", Integer, nullable=True),
    Column("fandoms", JSON, nullable=True),
    Column("error", Text, nullable=True),
    Column("restricted", Boolean, nullable=False, server_default=text("0")),
    Column("needs_auth", Boolean, nullable=False, server_default=text("0")),
)

queue = Table(
    "queue", metadata,
    Column("id", BigInteger, primary_key=True),
    Column("mode", String(16), nullable=False, server_default=text("'guest'")),  # guest|auth|update
    Column("priority", Integer, nullable=False, server_default=text("100")),
    Column("next_attempt", DateTime, nullable=False, server_default=func.now()),
    Column("attempts", Integer, nullable=False, server_default=text("0")),
    Column("locked_by", String(64), nullable=True),
    Column("locked_at", DateTime, nullable=True),
)

fetch_log = Table(
    "fetch_log", metadata,
    Column("id", BigInteger, nullable=False),
    Column("ts", DateTime, nullable=False, server_default=func.now()),
    Column("worker", String(64), nullable=False),
    Column("outcome", String(32), nullable=False),  # public|restricted|unrevealed|not_found|error
    Column("http_status", Integer, nullable=True),
    Column("size_bytes", Integer, nullable=True),
    Column("error", Text, nullable=True),
    Index("fetch_log_id_ts", "id", "ts"),
)


def get_engine() -> Engine:
    return create_engine(DB_URL, pool_pre_ping=True, future=True)


def create_all():
    engine = get_engine()
    metadata.create_all(engine)


def enqueue_range(session: Session, start: int, stop: int, mode: str = "guest", priority: int = 100):
    rows = [{"id": i, "mode": mode, "priority": priority} for i in range(start, stop + 1)]
    if not rows:
        return 0
    dialect = session.bind.dialect.name
    if dialect == "sqlite":
        session.execute(text("INSERT OR IGNORE INTO queue (id, mode, priority) VALUES " + ",".join(
            f"({r['id']}, '{mode}', {priority})" for r in rows
        )))
    else:
        session.execute(queue.insert().prefix_with("ON CONFLICT DO NOTHING"), rows)
    return len(rows)

def claim_batch(session: Session, worker_id: str, batch_size: int, mode: str):
    dialect = session.bind.dialect.name
    if dialect == "postgresql":
        stmt = text("""
            UPDATE queue q
            SET locked_by = :worker, locked_at = NOW()
            WHERE q.id IN (
                SELECT id FROM queue
                WHERE mode = :mode AND (locked_by IS NULL) AND next_attempt <= NOW()
                ORDER BY priority ASC, id ASC
                FOR UPDATE SKIP LOCKED
                LIMIT :lim
            )
            RETURNING q.id
        """)
        res = session.execute(stmt, {"worker": worker_id, "lim": batch_size, "mode": mode})
        ids = [r[0] for r in res.fetchall()]
    else:
        # SQLite fallback
        ids = [r.id for r in session.execute(
            select(queue.c.id)
            .where(queue.c.mode == mode)
            .where(queue.c.locked_by.is_(None))
            .where(queue.c.next_attempt <= func.now())
            .order_by(queue.c.priority.asc(), queue.c.id.asc())
            .limit(batch_size)
        )]
        if ids:
            session.execute(update(queue).where(queue.c.id.in_(ids)).values(locked_by=worker_id, locked_at=func.now()))
    return ids

def requeue(session: Session, id_: int, delay_seconds: int, error_msg: Optional[str] = None):
    dialect = session.bind.dialect.name
    if dialect == "postgresql":
        session.execute(text("""
            UPDATE queue
            SET attempts = attempts + 1,
                locked_by = NULL,
                locked_at = NULL,
                next_attempt = NOW() + (:delay || ' seconds')::interval
            WHERE id = :id
        """), {"id": id_, "delay": delay_seconds})
    else:
        session.execute(text("""
            UPDATE queue
            SET attempts = attempts + 1,
                locked_by = NULL,
                locked_at = NULL,
                next_attempt = datetime('now', '+' || :delay || ' seconds')
            WHERE id = :id
        """), {"id": id_, "delay": delay_seconds})
    if error_msg:
        session.execute(fetch_log.insert().values(id=id_, outcome="error", error=error_msg))

def complete(session: Session, id_: int):
    session.execute(queue.delete().where(queue.c.id == id_))
