
from __future__ import annotations
import time
from typing import Optional, Tuple

from .sessions import guest_get, load_credentials, Credential, jitter
from .classify import classify_response, parse_basic_fields_html
from .storage import write_html_gz, write_json
from .config import AUTH_DELAY_S

BASE = "https://archiveofourown.org/works/{id}?view_full_work=true"

def probe_guest(id_: int) -> tuple[str, int, str, str]:
    url = BASE.format(id=id_)
    resp = guest_get(url)
    outcome = classify_response(url, resp.status_code, resp.text, resp.url)
    return (outcome, resp.status_code, resp.text, resp.url)

def fetch_authenticated(id_: int, creds: list[Credential]) -> tuple[str, int, str, str, Optional[str]]:
    url = BASE.format(id=id_)
    if not creds:
        return ("error", 0, "", url, "no-credentials")
    cred = creds[0]
    req = cred.ensure()
    time.sleep(jitter(AUTH_DELAY_S))
    resp = req.get(url, allow_redirects=True, force_session=cred.session)
    outcome = classify_response(url, resp.status_code, resp.text, resp.url)
    return (outcome, resp.status_code, resp.text, resp.url, None)
