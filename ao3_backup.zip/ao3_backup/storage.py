
"""
Does the work of actually storing the output files from ao3.
"""

from __future__ import annotations

from pathlib import Path
import gzip, json, hashlib

from ao3_backup.config import STORE_ROOT

def get_file_sytem_path(id_: int, )


def work_path(id_: int) -> Path:
    """
    Generate a work path which will be used to store the actual data files off the site.

    :param id_:
    :return:
    """
    m = id_ // 1_000_000
    k = (id_ // 1_000) % 1000
    return STORE_ROOT / "works" / f"{m:03d}" / f"{k:03d}" / f"{id_:09d}.html.gz"


def json_path(id_: int) -> Path:
    """
    Path to the metadata file which will be used to store basic metadata for the work.

    :param id_:
    :return:
    """
    m = id_ // 1_000_000
    k = (id_ // 1_000) % 1000
    return STORE_ROOT / "works" / f"{m:03d}" / f"{k:03d}" / f"{id_:09d}.json"


def write_html_gz(id_: int, html: str) -> tuple[int, str]:
    p = work_path(id_)
    p.parent.mkdir(parents=True, exist_ok=True)
    data = html.encode("utf-8", errors="replace")
    with gzip.open(p, "wb", compresslevel=6) as f:
        f.write(data)
    sha = hashlib.sha256(data).hexdigest()
    return len(data), sha


def write_json(id_: int, obj: dict) -> None:
    p = json_path(id_)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
