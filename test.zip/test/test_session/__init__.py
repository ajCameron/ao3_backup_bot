
"""
Contains the tests for the session class.
"""